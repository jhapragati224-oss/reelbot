"""Finds fresh stories from your sources (RSS links or keywords), ranks them, and asks you to approve."""
import re, json, pathlib, datetime, email.utils, requests
import xml.etree.ElementTree as ET
from urllib.parse import quote
import bot, studio

UA = {"User-Agent": "Mozilla/5.0"}


def fetch(src, hours):
    url = src if src.startswith("http") else (
        "https://news.google.com/rss/search?q=" + quote(f"{src} when:{hours}h") + "&hl=en-IN&gl=IN&ceid=IN:en")
    root = ET.fromstring(requests.get(url, headers=UA, timeout=30).content)
    cutoff = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(hours=hours)
    out = []
    for it in root.iter("item"):
        try:
            fresh = email.utils.parsedate_to_datetime(it.findtext("pubDate")) >= cutoff
        except Exception:
            fresh = True
        if fresh and it.findtext("title"):
            out.append({"title": it.findtext("title").strip(), "src": (it.findtext("source") or src)[:60]})
    return out[:15]


def suggest(sources, hours, n):
    items, seen = [], set()
    for s in sources:
        try:
            got = fetch(s, hours)
        except Exception:
            continue
        for it in got:
            k = re.sub(r"\W+", "", it["title"].lower())[:40]
            if k not in seen:
                seen.add(k); items.append(it)
    items = items[:60]
    if not items:
        bot.say("No fresh stories found for: " + ", ".join(sources))
        return
    listing = "\n".join(f"{i}. {x['title']}" for i, x in enumerate(items))
    p = f"""Pick the {n} stories most likely to work as a viral 30-second reel for an Indian news and current-affairs Instagram page:
high curiosity, strong emotion, easy to share, clear visuals. Skip unverified rumours, communal flashpoints and graphic violence. Merge near-duplicates.
Return ONLY a JSON list: [{{"i": index, "why": "one sentence", "angle": "a fresh hook angle in one sentence"}}]
STORIES:
{listing}"""
    picks = studio.jparse(studio.gem(p))
    kb = json.dumps({"inline_keyboard": [[{"text": "Make reel", "callback_data": "mk:1"},
                                          {"text": "Skip", "callback_data": "sk:1"}]]})
    for pk in picks[:n]:
        x = items[int(pk["i"])]
        bot.tg("sendMessage", chat_id=bot.CHAT, reply_markup=kb,
               text=f"{x['title']}\nSource: {x['src']}\nWhy: {pk['why']}\nAngle: {pk['angle']}"[:4000])


if __name__ == "__main__":
    f = pathlib.Path("sources.txt")
    srcs = [l.strip() for l in f.read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")] if f.exists() else ["India news"]
    suggest(srcs, int(bot.E.get("HOURS", "8")), int(bot.E.get("N", "3")))
